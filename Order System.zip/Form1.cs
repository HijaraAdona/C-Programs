using System.Diagnostics.Metrics;

namespace Order_System_Prelim
{
    public partial class Form1 : Form
    {
        private decimal prodValue1 = 0;
        private decimal prodValue2 = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void up1_Click(object sender, EventArgs e)
        {
            prodValue1++;
            prod1.Text = prodValue1.ToString();
            UpdateTotal();
        }

        private void down1_Click(object sender, EventArgs e)
        {
            prodValue1--;
            prod1.Text = prodValue1.ToString();
            UpdateTotal();
        }

        private void total_TextChanged(object sender, EventArgs e)
        {

        }

        private decimal CalculateOverall()
        {
            decimal price1Value = 12 * prodValue1;
            decimal price2Value = 13 * prodValue2;
            return price1Value + price2Value;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void up2_Click(object sender, EventArgs e)
        {
            prodValue2++;
            prod2.Text = prodValue2.ToString();
            UpdateTotal();
        }

        private void down2_Click(object sender, EventArgs e)
        {
            prodValue2--;
            prod2.Text = prodValue2.ToString();
            UpdateTotal();
        }

        private void prod2_TextChanged(object sender, EventArgs e)
        {
            decimal pricef2;
            pricef2 = 13 * prodValue2;
            price2.Text = pricef2.ToString("$0.00");
        }

        private void prod1_TextChanged(object sender, EventArgs e)
        {
            decimal pricef1 = 12 * prodValue1;
            price1.Text = pricef1.ToString("$0.00");
        }

        private void price1_Click(object sender, EventArgs e)
        {

        }

        private void price2_Click(object sender, EventArgs e)
        {

        }

        private void delete2_Click(object sender, EventArgs e)
        {
            string quantity = " ";
            price2.Text = string.Empty;
            total.Text = string.Empty;
            prod2.Text = quantity;
        }

        private void delete1_Click_1(object sender, EventArgs e)
        {
            string quantity = " ";
            prod1.Text = quantity;
            price1.Text = string.Empty;
            total.Text= string.Empty;
        }

        private void UpdateTotal()
        {
            decimal overall = CalculateOverall();
            total.Text = overall.ToString("$0.00");
        }
    }
}
