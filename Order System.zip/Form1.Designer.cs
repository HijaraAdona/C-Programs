﻿namespace Order_System_Prelim
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            up1 = new Label();
            down1 = new Label();
            label12 = new Label();
            total = new TextBox();
            down2 = new Label();
            up2 = new Label();
            price1 = new Label();
            price2 = new Label();
            delete2 = new Label();
            prod2 = new TextBox();
            prod1 = new TextBox();
            delete1 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 39);
            label1.Name = "label1";
            label1.Size = new Size(53, 20);
            label1.TabIndex = 0;
            label1.Text = "Burger";
            // 
            // up1
            // 
            up1.AutoSize = true;
            up1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            up1.Location = new Point(272, 29);
            up1.Name = "up1";
            up1.Size = new Size(39, 41);
            up1.TabIndex = 1;
            up1.Text = "+";
            up1.Click += up1_Click;
            // 
            // down1
            // 
            down1.AutoSize = true;
            down1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            down1.Location = new Point(210, 28);
            down1.Name = "down1";
            down1.Size = new Size(30, 41);
            down1.TabIndex = 2;
            down1.Text = "-";
            down1.Click += down1_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(32, 93);
            label12.Name = "label12";
            label12.Size = new Size(39, 20);
            label12.TabIndex = 6;
            label12.Text = "Fries";
            // 
            // total
            // 
            total.Location = new Point(338, 143);
            total.Name = "total";
            total.Size = new Size(101, 27);
            total.TabIndex = 12;
            total.TextChanged += total_TextChanged;
            // 
            // down2
            // 
            down2.AutoSize = true;
            down2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            down2.Location = new Point(210, 76);
            down2.Name = "down2";
            down2.Size = new Size(30, 41);
            down2.TabIndex = 14;
            down2.Text = "-";
            down2.Click += down2_Click;
            // 
            // up2
            // 
            up2.AutoSize = true;
            up2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            up2.Location = new Point(272, 77);
            up2.Name = "up2";
            up2.Size = new Size(39, 41);
            up2.TabIndex = 13;
            up2.Text = "+";
            up2.Click += up2_Click;
            // 
            // price1
            // 
            price1.AutoSize = true;
            price1.BackColor = Color.Transparent;
            price1.ForeColor = SystemColors.ControlText;
            price1.ImageAlign = ContentAlignment.BottomLeft;
            price1.Location = new Point(343, 46);
            price1.Name = "price1";
            price1.Size = new Size(0, 20);
            price1.TabIndex = 18;
            price1.TextAlign = ContentAlignment.MiddleCenter;
            price1.Click += price1_Click;
            // 
            // price2
            // 
            price2.AutoSize = true;
            price2.BackColor = Color.Transparent;
            price2.ForeColor = SystemColors.ControlText;
            price2.ImageAlign = ContentAlignment.BottomLeft;
            price2.Location = new Point(343, 94);
            price2.Name = "price2";
            price2.Size = new Size(0, 20);
            price2.TabIndex = 20;
            price2.TextAlign = ContentAlignment.MiddleCenter;
            price2.Click += price2_Click;
            // 
            // delete2
            // 
            delete2.AutoSize = true;
            delete2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            delete2.Location = new Point(416, 85);
            delete2.Name = "delete2";
            delete2.Size = new Size(23, 28);
            delete2.TabIndex = 19;
            delete2.Text = "x";
            delete2.Click += delete2_Click;
            // 
            // prod2
            // 
            prod2.Location = new Point(235, 89);
            prod2.Name = "prod2";
            prod2.Size = new Size(43, 27);
            prod2.TabIndex = 21;
            prod2.TextChanged += prod2_TextChanged;
            // 
            // prod1
            // 
            prod1.Location = new Point(235, 40);
            prod1.Name = "prod1";
            prod1.Size = new Size(43, 27);
            prod1.TabIndex = 22;
            prod1.TextChanged += prod1_TextChanged;
            // 
            // delete1
            // 
            delete1.AutoSize = true;
            delete1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            delete1.Location = new Point(416, 36);
            delete1.Name = "delete1";
            delete1.Size = new Size(23, 28);
            delete1.TabIndex = 23;
            delete1.Text = "x";
            delete1.Click += delete1_Click_1;
            // 
            // button1
            // 
            button1.Location = new Point(0, 0);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 24;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(487, 187);
            Controls.Add(button1);
            Controls.Add(delete1);
            Controls.Add(prod1);
            Controls.Add(prod2);
            Controls.Add(price2);
            Controls.Add(delete2);
            Controls.Add(price1);
            Controls.Add(down2);
            Controls.Add(up2);
            Controls.Add(total);
            Controls.Add(label12);
            Controls.Add(down1);
            Controls.Add(up1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label up1;
        private Label down1;
        private Label label12;
        private TextBox total;
        private Label down2;
        private Label up2;
        private Label price1;
        private Label price2;
        private Label delete2;
        private TextBox prod2;
        private TextBox prod1;
        private Label delete1;
        private Button button1;
    }
}
